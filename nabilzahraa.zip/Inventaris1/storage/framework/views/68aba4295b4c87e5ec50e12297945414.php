<?php $__env->startSection('content'); ?>
<main class="container mt-5">
    <h3 class="mb-4">Form Input Produk</h3>

    <form action="<?php echo e(route('produk.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <!-- Nama Barang -->
        <div class="mb-3">
            <label for="nama" class="form-label">Nama Barang</label>
            <input type="text" name="nama" class="form-control" id="nama" required>
        </div>

        <!-- Harga -->
        <div class="mb-3">
            <label for="harga" class="form-label">Harga</label>
            <input type="number" name="harga" class="form-control" id="harga" required>
        </div>

        <!-- Stok -->
        <div class="mb-3">
            <label for="stok" class="form-label">Stok</label>
            <input type="number" name="stok" class="form-control" id="stok" required>
        </div>

        <!-- Keterangan -->
        <div class="mb-3">
            <label for="keterangan" class="form-label">Keterangan</label>
            <textarea name="keterangan" class="form-control" id="keterangan" rows="3"></textarea>
        </div>

        <!-- Tombol Submit dan Cancel -->
        <div class="mt-4">
            <button type="submit" class="btn btn-primary">Submit</button>
            <a href="<?php echo e(url('produk')); ?>" class="btn btn-secondary">Cancel</a>
        </div>
    </form>
</main>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.apps', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\Inventaris1\resources\views/produk/tambah.blade.php ENDPATH**/ ?>