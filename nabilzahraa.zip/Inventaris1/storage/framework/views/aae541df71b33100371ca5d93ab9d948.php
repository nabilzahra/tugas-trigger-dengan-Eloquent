<!DOCTYPE html>
<html lang="en">
    <head>
        <html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <title>Dashboard </title>
        <!-- <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" /> -->
        <link href="<?php echo e(asset('build/assets/app-ZzZ0suJz.css')); ?>" rel="stylesheet" />
        
        <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    </head>
    <body class="sb-nav-fixed">
        <?php echo $__env->make('layouts.partial.nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <div id="layoutSidenav">
            <!-- laout sidebarNav -->
             <?php echo $__env->make('layouts.partial.sidebarNav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
          
            <div id="layoutSidenav_content">
                <!-- main -->
                 <?php echo $__env->yieldContent('content'); ?>
                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid px-4">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy; Your Website 2023</div>
                            <div>
                                <a href="#">Privacy Policy</a>
                                &middot;
                                <a href="#">Terms &amp; Conditions</a>
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
        <!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script> -->
        <script src="<?php echo e(asset('build/assets/app-BTTmoT1y.js')); ?>"></script>
        
        <!-- <script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/umd/simple-datatables.min.js" crossorigin="anonymous"></script> -->
        <script src="<?php echo e(asset('assets/js/datatables-simple-demo.js')); ?>"></script>
    </body>
</html>
<?php /**PATH C:\laragon\www\Inventaris1\resources\views/welcome.blade.php ENDPATH**/ ?>