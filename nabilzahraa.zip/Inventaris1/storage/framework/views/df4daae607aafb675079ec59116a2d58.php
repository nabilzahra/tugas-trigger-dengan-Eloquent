     
     <?php $__env->startSection('content'); ?>
     <main class="container-fluid">
     <h3 class="text-center mt-3 mb-5">Daftar Produk</h3>
     <a href='<?php echo e(route('produk.create')); ?>' class="btn text-black" href="produk/tambah" style="background-color: pink; border-color: pink; margin-top: -10px;">Tambah
</a>

    </a>

     <table class="table">
    <thead>
        <tr>
            <th>No.</th>
            <th>Produk</th>
            <th>Stok</th>
            <th>Aksi</th> <!-- Tambah kolom Aksi -->
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($index + 1); ?></td>
            <td><?php echo e($item->nama_barang); ?></td>
            <td><?php echo e($item->stok); ?></td>
            <td>
                <!-- Tombol Edit -->
                <a href="<?php echo e(route('produk.edit', $item->id)); ?>" class="btn btn-sm btn-warning">
                    <i class="fas fa-edit"></i>
                </a>

                <!-- Tombol Hapus -->
                <form action="<?php echo e(route('produk.destroy', $item->id)); ?>" method="POST" style="display:inline;">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Yakin ingin hapus produk ini?')">
                        <i class="fas fa-trash-alt"></i>
                    </button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

     </main>
     <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.apps', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\Inventaris1\resources\views/produk/index.blade.php ENDPATH**/ ?>