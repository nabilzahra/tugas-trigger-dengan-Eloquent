<?php

namespace App\Http\Controllers;

use App\Models\Stokout;
use Illuminate\Http\Request;

class StokoutsController extends Controller
{
    public function index()
    {
        //
    }

    public function create()
    {
        //
    }

    public function store(Request $request)
    {
        //
    }

    public function show(Stokout $stokout)
    {
        //
    }

    public function edit(Stokout $stokout)
    {
        //
    }

    public function update(Request $request, Stokout $stokout)
    {
        //
    }

    public function destroy(Stokout $stokout)
    {
        //
    }
}
